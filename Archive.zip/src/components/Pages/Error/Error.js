import React from 'react'

function Error() {
  return (
    <>
    <main>
    {/* <div className="main"> */}
    <div className="err_con">
    <div className="error_container">
      <div className='error_heading'>There was a problem with executing your request</div>
      <div className='report_title'>Report problem and improve the quality of IT Computation Form</div>
      <div className='description'>We apologise for the inconvenience and thank you for your understanding.</div>
      
    </div>
    </div>
    {/* </div> */}
    </main>
    </>
  )
}

export default Error