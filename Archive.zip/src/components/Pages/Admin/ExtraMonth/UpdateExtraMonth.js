import React from 'react'
import Sidebar from '../../../Layouts/Sidebar/Sidebar'
import AuthHeader from '../../../Layouts/Header/AuthHeader'

function UpdateExtraMonth() {
  return (
    <>
     <Sidebar>
        <AuthHeader/>
    </Sidebar>
    
    </>
  )
}

export default UpdateExtraMonth