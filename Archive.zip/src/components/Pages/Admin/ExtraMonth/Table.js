import React from 'react'

function Table() {
  return (
    <>
    
    
    
    
    </>
  )
}

export default Table