import React from 'react'

function Pension() {
  return (
    <div>Pension</div>
  )
}

export default Pension