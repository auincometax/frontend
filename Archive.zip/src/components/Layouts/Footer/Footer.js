import React from 'react'

function Footer() {
  return (
   <>
   
   
   <div className="special_thanks  py-2" style={{fontSize:'0.9rem'}}>
                <div className="sublinks">
                <div className=" blink " >Useful Links:</div>
                <div>
                  <a href="https://www.wbifms.gov.in/cas/login?service=http%3A%2F%2Fwww.wbifms.gov.in%2Fhrms-ess%2Femployee%2Fhome.html" target={"_blank"}>Download Pay Slip</a>
                </div>
                <div>
               <a href="https://aliah.ac.in/IT%20Calculation%20Form/build/" target={"_blank"}>Old Website</a>
               </div>
                <div>
                 <a href="https://incometaxindia.gov.in/pages/tools/income-tax-calculator.aspx" target={"_blank"}>Income Tax Calculator</a>
                </div>

               <div>
               <a href="https://www.india.gov.in/spotlight/union-budget-2024-25" target={"_blank"}>Union Budget 2024</a>
               </div>

                <div>
                <a href="https://incometaxindia.gov.in/pages/communications/index.aspx" target={"_blank"}>Income Tax Notice</a>
                </div>
             
               <div>
               <a href="https://eportal.incometax.gov.in/iec/foservices/#/pre-login/bl-link-aadhaar" target={"_blank"}>Link  Aadhaar with  your PAN</a>
               </div>
                

                
                

                </div>
                <div className="sublinks2">
                    <div>
                      <div className='sub_heading'>Developed By</div>
                      <div>Mr. Bikram Shit (MCA232001), Student, Dept. of CSE</div>
                      <div>Mr. Shaikh Rizwan, Office Assistant, Office of the Finance Officer</div>
                    </div>
                    <div>
                      <div className='sub_heading'>Special Thanks to</div>
                      <div>Dr. Sk. Md. Mosaddek Hossain, Asstt. Prof. Department of CSE</div>
                      <div>Dr. Ayan Majumder, Asstt. Prof., Dept. of MBA</div>
                      <div>Mr. Asif Iqbal, Technical Assistant, Department of CSE</div>
                    </div>
                    <div>
                      <div className='sub_heading'>Supported By</div>
                      <div>Website Committee</div>
                      <div>Dr. Syed Nurus Salam (Former Registrar)</div>
                      <div>Mr. Pulak Kumar Mandal (Former Finance Officer)</div>
                      



                    </div>
                </div>
                </div>


   
   </>
  )
}

export default Footer