import React from 'react'

function Intro() {
  return (
    <>
    
    <div className="intro">
        <span>Here You Can Compute Your Tax Comfortably and Efficiently </span>
          <span>  Without Using Any Paper, Pen or Calculator</span>
          <span>

            - Shaikh Rizwan
          </span>

<span>
Sr. Accounts Assistant, A Torab & Co., Chartered Accountants</span> 

    </div>
    
    
    </>
  )
}

export default Intro