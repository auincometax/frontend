import React from 'react'
function Loader() {
  return (
    <>

      <div className="loader_Div">
      <div class="loader">
    <div class="circle"></div>
    <div class="circle"></div>
    <div class="circle"></div>
    <div class="circle"></div>
</div>
      </div>

    </>
  )
}

export default Loader